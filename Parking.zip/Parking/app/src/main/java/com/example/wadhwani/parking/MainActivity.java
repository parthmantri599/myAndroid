package com.example.wadhwani.parking;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.security.acl.LastOwnerException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, LocationListener, GoogleMap.OnPolygonClickListener, GoogleMap.OnPolylineClickListener ,Serializable, GoogleMap.OnMarkerClickListener {
    private GoogleMap mgooglemap;
    private static final int LOCATION_REQUEST = 500;
    public Spinner spinner;
    ActionBar actionBar;
    public LatLng abc;
    public String x;
    public Polyline polyline1,polyline2;
    public String totalp="10",avail="10";
    public String totalpc="2",availc="2";
    public EditText ed1;
    public String poly1,poly2;
    public String reg1 = "^[a-z]{2}[0-9]{2}[a-z]{1,2}[0-9]{4}$";
    public  int a,b;
    public double latitude;
    public double longit;
    public int userp=1;
    public SharedPreferences mn;
    public SharedPreferences.Editor mne;
    public SharedPreferences up;
    public SharedPreferences.Editor upe;
    public SharedPreferences pp;
    public SharedPreferences.Editor ppe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        actionBar=getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayUseLogoEnabled(true);
        mn=getSharedPreferences("Parking",MODE_PRIVATE);
        mne=mn.edit();
        up=getSharedPreferences("userp",MODE_PRIVATE);
        upe=up.edit();
        pp=getSharedPreferences("pp",MODE_PRIVATE);
        ppe=pp.edit();
        SupportMapFragment mapFragment1 = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment1.getMapAsync((OnMapReadyCallback) this);

    }

    public void onMapReady(GoogleMap googleMap) {
        mgooglemap = googleMap;
/*
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }*/
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_REQUEST);
            return;
        }


        mgooglemap.setMyLocationEnabled(true);
        mgooglemap.setOnMarkerClickListener(this);
        LocationManager locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,4000000,1000,this);

                 polyline1 = googleMap.addPolyline(new PolylineOptions()//chandivali
                .clickable(true)
                .add(
                        new LatLng(19.11485, 72.89292),
                        new LatLng(19.11481, 72.89287),
                        new LatLng(19.1148, 72.89289),
                        new LatLng(19.11483, 72.89294),
                        new LatLng(19.11485, 72.89292)
                        ));
         polyline2=googleMap.addPolyline(new PolylineOptions().clickable(true).add(//mindspace
                new LatLng(19.173704, 72.831124),
                new LatLng(19.173995, 72.831190),
                new LatLng(19.173997, 72.831172),
                new LatLng(19.173705, 72.831105),
                new LatLng(19.173704, 72.831124)

        )
        );

        poly1=polyline1.getId();
        poly2=polyline2.getId();
       /* Calendar calendar=Calendar.getInstance();
        int day=calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH);*/
        //if(Integer.parseInt(avail)!=0)
        if(Integer.parseInt(avail)>5)
       polyline2.setColor(0xff388E3C);
        else if(Integer.parseInt(avail)<=5&&Integer.parseInt(avail)>0||up.getString("key","").equals("done"))
            polyline2.setColor(Color.YELLOW);
        else if(Integer.parseInt(avail)==0)
            polyline2.setColor(Color.RED);
        if(Integer.parseInt(availc)>=1)
        polyline1.setColor(0xff388E3C);
        if(Integer.parseInt(availc)==1)
            polyline1.setColor(Color.YELLOW);
        if(Integer.parseInt(availc)==0)
            polyline1.setColor(Color.RED);

        mgooglemap.setOnPolylineClickListener(this);
        mgooglemap.setOnPolygonClickListener(this);
    }


    @Override
    public void onLocationChanged(Location location) {

         abc=new LatLng(location.getLatitude(),location.getLongitude());
        CameraUpdate cameraUpdate=CameraUpdateFactory.newLatLngZoom(abc,20);
        //mgooglemap.animateCamera(cameraUpdate);
        CameraPosition cameraPosition=new CameraPosition.Builder()
                .target(abc)
                .zoom(17)
                .bearing(90)
                .build();
        mgooglemap.moveCamera(CameraUpdateFactory.newLatLngZoom(abc,17));
        Marker marker=mgooglemap.addMarker(new MarkerOptions().position(abc).icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));
        //onMarkerClick(marker);
        //mgooglemap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
       }


    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onPolygonClick(Polygon polygon) {
        }

    @Override
    public void onPolylineClick(Polyline polyline) {
        if (up.getString("key","").equals("")){
            if (polyline.getColor() == 0xff388E3C || polyline.getColor() == Color.YELLOW) {

                // showAlert();
                final AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                View view = inflater.inflate(R.layout.popup, null);
                alert.setView(view);

                alert.setTitle("Booking Window");
                alert.setMessage("Welcome to booking window!!");
                alert.setCancelable(false);
                final AlertDialog dialog = alert.create();
                if (polyline.getId().equals(poly2)) {//mindspace
                    TextView tot = (TextView) view.findViewById(R.id.total);
                    tot.setText(totalp);
                    a = 2;
                    TextView av = (TextView) view.findViewById(R.id.avail);
                    av.setText(avail);
                }
                if (polyline.getId().equals(poly1)) {//chandivali
                    TextView tot = (TextView) view.findViewById(R.id.total);
                    tot.setText(totalpc);
                    a = 1;
                    TextView av = (TextView) view.findViewById(R.id.avail);
                    av.setText(availc);
                }
                ed1 = (EditText) view.findViewById(R.id.ed1);
                Button btn_book = (Button) view.findViewById(R.id.btn_book);
                btn_book.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (ed1.getText().toString().length() == 0) {
                            Toast.makeText(MainActivity.this, "Please enter the details", Toast.LENGTH_SHORT).show();
                            ed1.setHint("Please Fill the details");
                            ed1.setHintTextColor(Color.RED);
                        }
                        if (ed1.getText().toString().length() > 0) {
                            Pattern p = Pattern.compile(reg1);
                            Matcher m = p.matcher(ed1.getText().toString());
                            boolean b = m.matches();
                            if (b) {
                                if (a == 2) {
                                    int x = Integer.parseInt(avail);
                                    --x;
                                    userp--;
                                    upe.putString("key","done");
                                    upe.commit();

                                    avail = Integer.toString(x);
                                    ppe.putString("key",avail);
                                    ppe.commit();
                                    mne.putString("key","mindspace");
                                    mne.commit();
                                    if (x == 0&&up.getString("key","").equals("done")) {
                                        polyline2.setColor(Color.RED);
                                        //polyline2.setClickable(false);
                                    }
                                    if(x<=5&&up.getString("key","").equals("done"))
                                        polyline2.setColor(Color.YELLOW);
                                } else if (a == 1) {
                                    int x = Integer.parseInt(availc);
                                    --x;
                                    userp--;
                                    upe.putString("key","done");
                                    upe.commit();
                                    availc = Integer.toString(x);
                                    ppe.putString("key",availc);
                                    ppe.commit();
                                    mne.putString("key","chandivali");
                                    mne.commit();
                                    if (x == 0&&up.getString("key","").equals("done")) {
                                        polyline1.setColor(Color.RED);
                                        //polyline1.setClickable(false);
                                    }
                                    if (x == 1&&up.getString("key","").equals("done")) {
                                        polyline1.setColor(Color.YELLOW);
                                    }
                                }
                                String z = "Slot Booked for " + ed1.getText().toString();
                                Toast.makeText(MainActivity.this, z, Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            } else {
                                Toast.makeText(MainActivity.this, "Enter valid vehicle number", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                                dialog.show();
                                ed1.setText("");
                                ed1.setHint("Ex:MH02AP0397");
                                ed1.setHintTextColor(Color.RED);
                            }
                        }
                    }
                });
                Button btn_notnow = (Button) view.findViewById(R.id.btn_notnow);
                btn_notnow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "Ok", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            } else if (polyline.getColor() == Color.RED ) {

                Toast.makeText(this, "Parking not Available", Toast.LENGTH_LONG).show();
            }
    }
    else{
            Toast.makeText(MainActivity.this,"You have booked your parking",Toast.LENGTH_SHORT).show();
        }

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
       switch (item.getItemId()){
           case R.id.exit:finish();
                            return true;
           case R.id.cancel:String value=mn.getString("key","");
                            if (value.equals("chandivali")&&up.getString("key","").equals("done")){
                                userp++;
                                upe.putString("key","");
                                upe.commit();
                                int z=Integer.parseInt(pp.getString("key",""));
                                z++;
                                availc=Integer.toString(z);
                                if(z==1&&up.getString("key","").equals("done")){
                                    polyline1.setColor(Color.YELLOW);
                                }
                                if(z==2&&up.getString("key","").equals("")){
                                    polyline1.setColor(0xff388E3C);
                                }
                                availc=Integer.toString(z);
                                mne.putString("key","");
                                mne.commit();
                                return true;
                            }
                        if (value.equals("mindspace")&&up.getString("key","").equals("done")){

                            upe.putString("key","");
                            upe.commit();
                            int z=Integer.parseInt(pp.getString("key",""));
                            z++;
                            avail=Integer.toString(z);
                            if(z<=5&&up.getString("key","").equals("done")){
                                polyline2.setColor(Color.YELLOW);
                            }
                            if(z==10&&up.getString("key","").equals("done"))
                                polyline2.setColor(0xff388E3C);

                            avail=Integer.toString(z);
                            mne.putString("key","");
                            mne.commit();
                            return true;
                            }
                            if(up.getString("key","").equals("done")){
                                Toast.makeText(MainActivity.this,"No parking booked from your side",Toast.LENGTH_SHORT).show();
                                return true;
                        }



        }
        return(super.onOptionsItemSelected(item));
    }


    @Override
    public boolean onMarkerClick(Marker marker) {
        Marker marker1=mgooglemap.addMarker(new MarkerOptions().position(abc).title("Alredy parked"));
        marker1.setTitle("ALREADY BOOKED");
        marker.remove();
        marker1.showInfoWindow();
        //GroundOverlay groundOverlay=mgooglemap.addGroundOverlay(new GroundOverlayOptions().image(BitmapDescriptorFactory.fromResource(R.drawable.patch)));
        return true;
    }
}




